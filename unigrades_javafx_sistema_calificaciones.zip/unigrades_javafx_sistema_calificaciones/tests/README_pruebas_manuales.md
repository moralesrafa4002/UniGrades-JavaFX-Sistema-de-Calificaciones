# Pruebas manuales sugeridas

1. Iniciar sesión con administrador.
2. Crear una carrera.
3. Crear una materia con porcentajes 70 y 30.
4. Intentar crear una materia con porcentajes 90 y 20 para comprobar validación.
5. Crear profesor.
6. Crear alumno.
7. Crear grupo.
8. Inscribir alumno.
9. Entrar como profesor.
10. Registrar calificación válida.
11. Registrar calificación inválida mayor a 10 para comprobar alerta.
12. Entrar como alumno y consultar resultado.
