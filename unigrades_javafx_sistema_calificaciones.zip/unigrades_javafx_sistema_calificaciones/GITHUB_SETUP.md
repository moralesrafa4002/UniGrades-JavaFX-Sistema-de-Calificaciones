# Guía para subir el proyecto a GitHub

Este archivo explica cómo crear el repositorio en GitHub y subir el proyecto.

## 1. Crear repositorio en GitHub

Entra a GitHub y crea un repositorio nuevo, por ejemplo:

```text
unigrades-javafx-calificaciones
```

Puedes dejarlo público o privado según lo indique el profesor.

## 2. Abrir terminal en la carpeta del proyecto

Descomprime el ZIP y abre una terminal dentro de la carpeta principal.

## 3. Inicializar Git

```bash
git init
git add .
git commit -m "Proyecto JavaFX sistema de calificaciones universitarias"
git branch -M main
```

## 4. Conectar con GitHub

Cambia `USUARIO` por tu usuario de GitHub:

```bash
git remote add origin https://github.com/USUARIO/unigrades-javafx-calificaciones.git
```

## 5. Subir archivos

```bash
git push -u origin main
```

## 6. Actualizar cambios futuros

Cada vez que hagas cambios:

```bash
git add .
git commit -m "Actualización del proyecto"
git push
```
