package com.rafa.unigrades.model;

public class Grupo {
    private int id;
    private int idMateria;
    private int idProfesor;
    private String periodo;
    private String nombreGrupo;

    public Grupo() {}

    public Grupo(int id, int idMateria, int idProfesor, String periodo, String nombreGrupo) {
        this.id = id;
        this.idMateria = idMateria;
        this.idProfesor = idProfesor;
        this.periodo = periodo;
        this.nombreGrupo = nombreGrupo;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getIdMateria() { return idMateria; }
    public void setIdMateria(int idMateria) { this.idMateria = idMateria; }
    public int getIdProfesor() { return idProfesor; }
    public void setIdProfesor(int idProfesor) { this.idProfesor = idProfesor; }
    public String getPeriodo() { return periodo; }
    public void setPeriodo(String periodo) { this.periodo = periodo; }
    public String getNombreGrupo() { return nombreGrupo; }
    public void setNombreGrupo(String nombreGrupo) { this.nombreGrupo = nombreGrupo; }

    @Override
    public String toString() { return nombreGrupo + " - " + periodo; }
}
