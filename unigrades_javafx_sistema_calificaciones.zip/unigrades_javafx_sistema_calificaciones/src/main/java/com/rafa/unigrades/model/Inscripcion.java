package com.rafa.unigrades.model;

public class Inscripcion {
    private int id;
    private int idAlumno;
    private int idGrupo;

    public Inscripcion() {}

    public Inscripcion(int id, int idAlumno, int idGrupo) {
        this.id = id;
        this.idAlumno = idAlumno;
        this.idGrupo = idGrupo;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getIdAlumno() { return idAlumno; }
    public void setIdAlumno(int idAlumno) { this.idAlumno = idAlumno; }
    public int getIdGrupo() { return idGrupo; }
    public void setIdGrupo(int idGrupo) { this.idGrupo = idGrupo; }
}
