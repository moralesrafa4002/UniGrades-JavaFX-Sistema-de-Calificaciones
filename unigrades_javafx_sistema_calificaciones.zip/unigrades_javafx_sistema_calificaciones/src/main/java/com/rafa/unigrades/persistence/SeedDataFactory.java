package com.rafa.unigrades.persistence;

import com.rafa.unigrades.model.*;

public class SeedDataFactory {

    public DataStore createDefaultData() {
        DataStore store = new DataStore();
        store.setUniversidad(new Universidad(1, "Universidad del Proyecto"));

        store.getUsuarios().add(new Usuario(1, "Administrador General", "admin@universidad.edu", "admin123", TipoUsuario.ADMINISTRADOR));
        store.getUsuarios().add(new Usuario(2, "Profesor Demo", "profesor@universidad.edu", "profe123", TipoUsuario.PROFESOR));
        store.getUsuarios().add(new Usuario(3, "Alumno Demo", "alumno@universidad.edu", "alumno123", TipoUsuario.ALUMNO));
        store.getUsuarios().add(new Usuario(4, "Alumno Sistemas", "alumno2@universidad.edu", "alumno123", TipoUsuario.ALUMNO));

        store.getAdministradores().add(new Administrador(1, "ADM-001"));
        store.getProfesores().add(new Profesor(2, "PROF-001"));
        store.getAlumnos().add(new Alumno(3, "A-2026-001", 1));
        store.getAlumnos().add(new Alumno(4, "A-2026-002", 1));

        store.getCarreras().add(new Carrera(1, "Ingeniería en Sistemas Computacionales", 1));
        store.getCarreras().add(new Carrera(2, "Ingeniería Industrial", 1));

        for (int i = 1; i <= 8; i++) {
            store.getSemestres().add(new Semestre(i, i));
        }

        store.getMaterias().add(new Materia(1, "Programación Orientada a Objetos", 1, 3));
        store.getMaterias().add(new Materia(2, "Bases de Datos", 1, 4));
        store.getMaterias().add(new Materia(3, "Arquitectura de Computadoras", 1, 4));

        store.getGrupos().add(new Grupo(1, 1, 2, "2026-1", "SIS-POO-301"));
        store.getGrupos().add(new Grupo(2, 2, 2, "2026-1", "SIS-BD-401"));

        store.getInscripciones().add(new Inscripcion(1, 3, 1));
        store.getInscripciones().add(new Inscripcion(2, 4, 1));
        store.getInscripciones().add(new Inscripcion(3, 3, 2));

        store.getConfiguraciones().add(new ConfiguracionEvaluacion(1, 1, 70, 30, 6.0, 5));
        store.getConfiguraciones().add(new ConfiguracionEvaluacion(2, 2, 60, 40, 6.0, 5));
        store.getConfiguraciones().add(new ConfiguracionEvaluacion(3, 3, 80, 20, 6.0, 4));

        store.getCalificaciones().add(new Calificacion(1, 1, 8.0, 9.0, 7.5, 9.5, 1, 8.38, "APROBADO"));
        store.getCalificaciones().add(new Calificacion(2, 2, 5.0, 6.0, 5.5, 7.0, 2, 6.02, "APROBADO"));
        store.getCalificaciones().add(new Calificacion(3, 3, 9.0, 8.5, 9.5, 9.0, 0, 9.0, "APROBADO"));

        return store;
    }
}
