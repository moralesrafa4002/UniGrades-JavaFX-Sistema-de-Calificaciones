package com.rafa.unigrades.service;

import com.rafa.unigrades.model.*;
import com.rafa.unigrades.pattern.GradeCalculatorStrategy;
import com.rafa.unigrades.pattern.WeightedGradeCalculator;
import com.rafa.unigrades.repository.RepositoryContext;
import java.util.List;
import java.util.Optional;

public class GradeService {
    private final RepositoryContext context;
    private final GradeCalculatorStrategy calculator;

    public GradeService(RepositoryContext context) {
        this.context = context;
        this.calculator = new WeightedGradeCalculator();
    }

    public List<Calificacion> calificaciones() { return context.getStore().getCalificaciones(); }

    public Optional<Calificacion> buscarPorInscripcion(int idInscripcion) {
        return context.getStore().getCalificaciones().stream()
                .filter(c -> c.getIdInscripcion() == idInscripcion)
                .findFirst();
    }

    public ConfiguracionEvaluacion configuracionParaInscripcion(Inscripcion inscripcion) {
        Grupo grupo = context.getStore().getGrupos().stream()
                .filter(g -> g.getId() == inscripcion.getIdGrupo())
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Grupo no encontrado."));
        return context.getStore().getConfiguraciones().stream()
                .filter(c -> c.getIdMateria() == grupo.getIdMateria())
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Configuración de evaluación no encontrada."));
    }

    public Calificacion guardarCalificacion(Inscripcion inscripcion, double p1, double p2, double p3, double actividades, int faltas) {
        validarCalificacion(p1);
        validarCalificacion(p2);
        validarCalificacion(p3);
        validarCalificacion(actividades);
        if (faltas < 0) throw new IllegalArgumentException("Las faltas no pueden ser negativas.");

        Calificacion calificacion = buscarPorInscripcion(inscripcion.getId())
                .orElseGet(() -> {
                    Calificacion nueva = new Calificacion(context.getStore().nextCalificacionId(), inscripcion.getId(), 0, 0, 0, 0, 0, 0, "SIN EVALUAR");
                    context.getStore().getCalificaciones().add(nueva);
                    return nueva;
                });

        calificacion.setParcial1(p1);
        calificacion.setParcial2(p2);
        calificacion.setParcial3(p3);
        calificacion.setActividades(actividades);
        calificacion.setFaltas(faltas);

        recalcular(calificacion, configuracionParaInscripcion(inscripcion));
        context.save();
        return calificacion;
    }

    public void recalcular(Calificacion calificacion, ConfiguracionEvaluacion configuracion) {
        double promedio = calculator.calcularPromedioFinal(calificacion, configuracion);
        calificacion.setPromedioFinal(promedio);
        calificacion.setEstatus(calculator.determinarEstatus(calificacion, configuracion));
    }

    private void validarCalificacion(double value) {
        if (value < 0 || value > 10) {
            throw new IllegalArgumentException("Las calificaciones deben estar entre 0 y 10.");
        }
    }
}
