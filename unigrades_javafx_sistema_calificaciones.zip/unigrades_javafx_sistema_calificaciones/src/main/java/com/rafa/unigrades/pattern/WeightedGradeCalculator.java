package com.rafa.unigrades.pattern;

import com.rafa.unigrades.model.Calificacion;
import com.rafa.unigrades.model.ConfiguracionEvaluacion;

public class WeightedGradeCalculator implements GradeCalculatorStrategy {

    @Override
    public double calcularPromedioFinal(Calificacion calificacion, ConfiguracionEvaluacion configuracion) {
        double promedioParciales = (calificacion.getParcial1() + calificacion.getParcial2() + calificacion.getParcial3()) / 3.0;
        double ponderacionParciales = configuracion.getPorcentajeParciales() / 100.0;
        double ponderacionActividades = configuracion.getPorcentajeActividades() / 100.0;
        double resultado = (promedioParciales * ponderacionParciales) + (calificacion.getActividades() * ponderacionActividades);
        return Math.round(resultado * 100.0) / 100.0;
    }

    @Override
    public String determinarEstatus(Calificacion calificacion, ConfiguracionEvaluacion configuracion) {
        if (calificacion.getFaltas() > configuracion.getFaltasMaximas()) {
            return "REPROBADO POR FALTAS";
        }
        return calificacion.getPromedioFinal() >= configuracion.getCalificacionMinima() ? "APROBADO" : "REPROBADO";
    }
}
