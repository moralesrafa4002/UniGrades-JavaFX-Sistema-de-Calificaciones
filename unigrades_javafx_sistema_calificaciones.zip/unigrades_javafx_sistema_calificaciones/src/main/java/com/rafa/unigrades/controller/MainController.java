package com.rafa.unigrades.controller;

import com.rafa.unigrades.model.TipoUsuario;
import com.rafa.unigrades.model.Usuario;
import com.rafa.unigrades.pattern.SessionManager;
import com.rafa.unigrades.service.AcademicService;
import com.rafa.unigrades.service.AuthService;
import com.rafa.unigrades.service.GradeService;
import com.rafa.unigrades.ui.AdminDashboardView;
import com.rafa.unigrades.ui.AlumnoDashboardView;
import com.rafa.unigrades.ui.LoginView;
import com.rafa.unigrades.ui.ProfesorDashboardView;
import com.rafa.unigrades.util.AlertUtil;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainController {
    private final Stage stage;
    private final AuthService authService;
    private final AcademicService academicService;
    private final GradeService gradeService;

    public MainController(Stage stage, AuthService authService, AcademicService academicService, GradeService gradeService) {
        this.stage = stage;
        this.authService = authService;
        this.academicService = academicService;
        this.gradeService = gradeService;
    }

    public void login(String correo, String password) {
        authService.login(correo, password).ifPresentOrElse(usuario -> {
            SessionManager.getInstance().login(usuario);
            routeByRole(usuario);
        }, () -> AlertUtil.showError("Login incorrecto", "Correo o contraseña inválidos."));
    }

    public void logout() {
        SessionManager.getInstance().logout();
        LoginView view = new LoginView(this);
        setScene(view.getRoot(), "UniGrades JavaFX - Login");
    }

    private void routeByRole(Usuario usuario) {
        if (usuario.getTipo() == TipoUsuario.ADMINISTRADOR) {
            AdminDashboardView view = new AdminDashboardView(this, academicService, gradeService);
            setScene(view.getRoot(), "UniGrades JavaFX - Administrador");
        } else if (usuario.getTipo() == TipoUsuario.PROFESOR) {
            ProfesorDashboardView view = new ProfesorDashboardView(this, academicService, gradeService, usuario);
            setScene(view.getRoot(), "UniGrades JavaFX - Profesor");
        } else {
            AlumnoDashboardView view = new AlumnoDashboardView(this, academicService, gradeService, usuario);
            setScene(view.getRoot(), "UniGrades JavaFX - Alumno");
        }
    }

    private void setScene(javafx.scene.Parent root, String title) {
        Scene scene = new Scene(root, 980, 640);
        scene.getStylesheets().add(getClass().getResource("/styles/app.css").toExternalForm());
        stage.setTitle(title);
        stage.setScene(scene);
    }
}
