package com.rafa.unigrades.model;

public class ConfiguracionEvaluacion {
    private int id;
    private int idMateria;
    private double porcentajeParciales;
    private double porcentajeActividades;
    private double calificacionMinima;
    private int faltasMaximas;

    public ConfiguracionEvaluacion() {}

    public ConfiguracionEvaluacion(int id, int idMateria, double porcentajeParciales, double porcentajeActividades, double calificacionMinima, int faltasMaximas) {
        this.id = id;
        this.idMateria = idMateria;
        this.porcentajeParciales = porcentajeParciales;
        this.porcentajeActividades = porcentajeActividades;
        this.calificacionMinima = calificacionMinima;
        this.faltasMaximas = faltasMaximas;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getIdMateria() { return idMateria; }
    public void setIdMateria(int idMateria) { this.idMateria = idMateria; }
    public double getPorcentajeParciales() { return porcentajeParciales; }
    public void setPorcentajeParciales(double porcentajeParciales) { this.porcentajeParciales = porcentajeParciales; }
    public double getPorcentajeActividades() { return porcentajeActividades; }
    public void setPorcentajeActividades(double porcentajeActividades) { this.porcentajeActividades = porcentajeActividades; }
    public double getCalificacionMinima() { return calificacionMinima; }
    public void setCalificacionMinima(double calificacionMinima) { this.calificacionMinima = calificacionMinima; }
    public int getFaltasMaximas() { return faltasMaximas; }
    public void setFaltasMaximas(int faltasMaximas) { this.faltasMaximas = faltasMaximas; }
}
