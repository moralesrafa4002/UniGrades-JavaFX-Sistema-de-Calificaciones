package com.rafa.unigrades.pattern;

import com.rafa.unigrades.model.Calificacion;
import com.rafa.unigrades.model.ConfiguracionEvaluacion;

public interface GradeCalculatorStrategy {
    double calcularPromedioFinal(Calificacion calificacion, ConfiguracionEvaluacion configuracion);
    String determinarEstatus(Calificacion calificacion, ConfiguracionEvaluacion configuracion);
}
