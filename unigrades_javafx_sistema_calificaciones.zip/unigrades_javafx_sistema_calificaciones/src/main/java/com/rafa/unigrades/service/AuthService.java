package com.rafa.unigrades.service;

import com.rafa.unigrades.model.Usuario;
import com.rafa.unigrades.repository.RepositoryContext;
import java.util.Optional;

public class AuthService {
    private final RepositoryContext context;

    public AuthService(RepositoryContext context) {
        this.context = context;
    }

    public Optional<Usuario> login(String correo, String password) {
        return context.getStore().getUsuarios().stream()
                .filter(u -> u.getCorreo().equalsIgnoreCase(correo.trim()))
                .filter(u -> u.getPassword().equals(password))
                .findFirst();
    }
}
