package com.rafa.unigrades.model;

public class Calificacion {
    private int id;
    private int idInscripcion;
    private double parcial1;
    private double parcial2;
    private double parcial3;
    private double actividades;
    private int faltas;
    private double promedioFinal;
    private String estatus;

    public Calificacion() {}

    public Calificacion(int id, int idInscripcion, double parcial1, double parcial2, double parcial3, double actividades, int faltas, double promedioFinal, String estatus) {
        this.id = id;
        this.idInscripcion = idInscripcion;
        this.parcial1 = parcial1;
        this.parcial2 = parcial2;
        this.parcial3 = parcial3;
        this.actividades = actividades;
        this.faltas = faltas;
        this.promedioFinal = promedioFinal;
        this.estatus = estatus;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getIdInscripcion() { return idInscripcion; }
    public void setIdInscripcion(int idInscripcion) { this.idInscripcion = idInscripcion; }
    public double getParcial1() { return parcial1; }
    public void setParcial1(double parcial1) { this.parcial1 = parcial1; }
    public double getParcial2() { return parcial2; }
    public void setParcial2(double parcial2) { this.parcial2 = parcial2; }
    public double getParcial3() { return parcial3; }
    public void setParcial3(double parcial3) { this.parcial3 = parcial3; }
    public double getActividades() { return actividades; }
    public void setActividades(double actividades) { this.actividades = actividades; }
    public int getFaltas() { return faltas; }
    public void setFaltas(int faltas) { this.faltas = faltas; }
    public double getPromedioFinal() { return promedioFinal; }
    public void setPromedioFinal(double promedioFinal) { this.promedioFinal = promedioFinal; }
    public String getEstatus() { return estatus; }
    public void setEstatus(String estatus) { this.estatus = estatus; }
}
