package com.rafa.unigrades.repository;

import com.rafa.unigrades.model.DataStore;
import com.rafa.unigrades.persistence.XmlDatabase;

public class RepositoryContext {
    private final XmlDatabase xmlDatabase;
    private final DataStore store;

    public RepositoryContext(XmlDatabase xmlDatabase) {
        this.xmlDatabase = xmlDatabase;
        this.store = xmlDatabase.loadOrCreate();
    }

    public DataStore getStore() { return store; }

    public void save() { xmlDatabase.save(store); }
}
