package com.rafa.unigrades.util;

import javafx.scene.control.TextField;

public final class FormUtil {
    private FormUtil() {}

    public static String required(TextField field, String label) {
        String value = field.getText() == null ? "" : field.getText().trim();
        if (value.isBlank()) throw new IllegalArgumentException("El campo '" + label + "' es obligatorio.");
        return value;
    }

    public static double doubleValue(TextField field, String label) {
        try {
            return Double.parseDouble(required(field, label));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("El campo '" + label + "' debe ser numérico.");
        }
    }

    public static int intValue(TextField field, String label) {
        try {
            return Integer.parseInt(required(field, label));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("El campo '" + label + "' debe ser entero.");
        }
    }
}
