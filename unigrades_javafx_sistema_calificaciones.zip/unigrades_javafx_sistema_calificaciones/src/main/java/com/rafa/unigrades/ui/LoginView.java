package com.rafa.unigrades.ui;

import com.rafa.unigrades.controller.MainController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class LoginView {
    private final BorderPane root = new BorderPane();

    public LoginView(MainController controller) {
        VBox box = new VBox(14);
        box.setPadding(new Insets(35));
        box.setAlignment(Pos.CENTER);
        box.getStyleClass().add("login-card");

        Label title = new Label("UniGrades JavaFX");
        title.getStyleClass().add("title");
        Label subtitle = new Label("Sistema universitario de administración y consulta de calificaciones");
        subtitle.getStyleClass().add("subtitle");

        TextField correo = new TextField();
        correo.setPromptText("Correo institucional");
        correo.setMaxWidth(360);

        PasswordField password = new PasswordField();
        password.setPromptText("Contraseña");
        password.setMaxWidth(360);

        Button loginButton = new Button("Iniciar sesión");
        loginButton.getStyleClass().add("primary-button");
        loginButton.setMaxWidth(360);
        loginButton.setOnAction(e -> controller.login(correo.getText(), password.getText()));

        Label demo = new Label("Usuarios demo: admin@universidad.edu / admin123 | profesor@universidad.edu / profe123 | alumno@universidad.edu / alumno123");
        demo.getStyleClass().add("note");
        demo.setWrapText(true);
        demo.setMaxWidth(540);

        box.getChildren().addAll(title, subtitle, correo, password, loginButton, demo);
        root.setCenter(box);
    }

    public Parent getRoot() { return root; }
}
