package com.rafa.unigrades.ui;

import com.rafa.unigrades.controller.MainController;
import com.rafa.unigrades.model.*;
import com.rafa.unigrades.service.AcademicService;
import com.rafa.unigrades.service.GradeService;
import com.rafa.unigrades.util.AlertUtil;
import com.rafa.unigrades.util.FormUtil;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class AdminDashboardView {
    private final BorderPane root = new BorderPane();
    private final AcademicService academicService;
    private final GradeService gradeService;

    public AdminDashboardView(MainController controller, AcademicService academicService, GradeService gradeService) {
        this.academicService = academicService;
        this.gradeService = gradeService;
        root.setTop(header("Panel de Administración", controller));
        TabPane tabs = new TabPane();
        tabs.getTabs().add(new Tab("Carreras", carrerasTab()));
        tabs.getTabs().add(new Tab("Materias y configuración", materiasTab()));
        tabs.getTabs().add(new Tab("Usuarios", usuariosTab()));
        tabs.getTabs().add(new Tab("Grupos e inscripciones", gruposTab()));
        tabs.getTabs().add(new Tab("Calificaciones", calificacionesTab()));
        tabs.getTabs().forEach(t -> t.setClosable(false));
        root.setCenter(tabs);
    }

    private HBox header(String title, MainController controller) {
        Label label = new Label(title);
        label.getStyleClass().add("header-title");
        Button logout = new Button("Cerrar sesión");
        logout.setOnAction(e -> controller.logout());
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox box = new HBox(12, label, spacer, logout);
        box.setPadding(new Insets(14));
        box.getStyleClass().add("header");
        return box;
    }

    private Parent carrerasTab() {
        TableView<Carrera> table = ViewFactory.table();
        table.getColumns().add(ViewFactory.col("ID", "id", 60));
        table.getColumns().add(ViewFactory.col("Nombre", "nombre", 300));
        table.setItems(FXCollections.observableArrayList(academicService.carreras()));

        TextField nombre = new TextField();
        nombre.setPromptText("Nombre de la carrera");
        Button add = new Button("Agregar carrera");
        add.setOnAction(e -> {
            try {
                academicService.agregarCarrera(FormUtil.required(nombre, "Nombre"));
                table.setItems(FXCollections.observableArrayList(academicService.carreras()));
                nombre.clear();
            } catch (Exception ex) { AlertUtil.showError("No se pudo agregar", ex.getMessage()); }
        });

        Button delete = new Button("Eliminar seleccionada");
        delete.setOnAction(e -> {
            Carrera c = table.getSelectionModel().getSelectedItem();
            if (c != null) {
                academicService.eliminarCarrera(c);
                table.setItems(FXCollections.observableArrayList(academicService.carreras()));
            }
        });

        VBox form = new VBox(10, new Label("Alta de carrera"), nombre, add, delete);
        form.setPadding(new Insets(10));
        form.getStyleClass().add("side-card");
        BorderPane pane = new BorderPane(table);
        pane.setRight(form);
        pane.setPadding(new Insets(14));
        return pane;
    }

    private Parent materiasTab() {
        TableView<Materia> table = ViewFactory.table();
        table.getColumns().add(ViewFactory.col("ID", "id", 60));
        table.getColumns().add(ViewFactory.col("Materia", "nombre", 240));
        table.getColumns().add(ViewFactory.col("Carrera ID", "idCarrera", 90));
        table.getColumns().add(ViewFactory.col("Semestre ID", "idSemestre", 90));
        table.setItems(FXCollections.observableArrayList(academicService.materias()));

        TextField nombre = new TextField();
        nombre.setPromptText("Nombre de la materia");
        ComboBox<Carrera> carrera = new ComboBox<>(FXCollections.observableArrayList(academicService.carreras()));
        carrera.setPromptText("Carrera");
        ComboBox<Semestre> semestre = new ComboBox<>(FXCollections.observableArrayList(academicService.semestres()));
        semestre.setPromptText("Semestre");
        TextField pctParciales = new TextField("70");
        TextField pctActividades = new TextField("30");
        TextField minima = new TextField("6.0");
        TextField faltas = new TextField("5");
        Button add = new Button("Agregar materia");
        add.setOnAction(e -> {
            try {
                if (carrera.getValue() == null || semestre.getValue() == null) throw new IllegalArgumentException("Selecciona carrera y semestre.");
                academicService.agregarMateria(
                        FormUtil.required(nombre, "Materia"), carrera.getValue(), semestre.getValue(),
                        FormUtil.doubleValue(pctParciales, "% parciales"), FormUtil.doubleValue(pctActividades, "% actividades"),
                        FormUtil.doubleValue(minima, "Mínima aprobatoria"), FormUtil.intValue(faltas, "Faltas máximas")
                );
                table.setItems(FXCollections.observableArrayList(academicService.materias()));
                nombre.clear();
            } catch (Exception ex) { AlertUtil.showError("Validación", ex.getMessage()); }
        });
        Button delete = new Button("Eliminar materia");
        delete.setOnAction(e -> {
            Materia m = table.getSelectionModel().getSelectedItem();
            if (m != null) {
                academicService.eliminarMateria(m);
                table.setItems(FXCollections.observableArrayList(academicService.materias()));
            }
        });
        VBox form = new VBox(8, new Label("Nueva materia"), nombre, carrera, semestre, new Label("% Parciales"), pctParciales, new Label("% Actividades"), pctActividades, new Label("Mínima"), minima, new Label("Faltas máximas"), faltas, add, delete);
        form.setPadding(new Insets(10));
        form.getStyleClass().add("side-card");
        BorderPane pane = new BorderPane(table);
        pane.setRight(form);
        pane.setPadding(new Insets(14));
        return pane;
    }

    private Parent usuariosTab() {
        TableView<Usuario> table = ViewFactory.table();
        table.getColumns().add(ViewFactory.col("ID", "id", 60));
        table.getColumns().add(ViewFactory.col("Nombre", "nombre", 220));
        table.getColumns().add(ViewFactory.col("Correo", "correo", 260));
        table.getColumns().add(ViewFactory.col("Tipo", "tipo", 120));
        table.setItems(FXCollections.observableArrayList(academicService.usuarios()));

        TextField nombre = new TextField(); nombre.setPromptText("Nombre completo");
        TextField correo = new TextField(); correo.setPromptText("Correo");
        TextField pass = new TextField("123456"); pass.setPromptText("Contraseña");
        TextField extra = new TextField(); extra.setPromptText("Matrícula o número de empleado");
        ComboBox<Carrera> carrera = new ComboBox<>(FXCollections.observableArrayList(academicService.carreras())); carrera.setPromptText("Carrera del alumno");

        Button addProfesor = new Button("Agregar profesor");
        addProfesor.setOnAction(e -> {
            try {
                academicService.agregarProfesor(FormUtil.required(nombre, "Nombre"), FormUtil.required(correo, "Correo"), FormUtil.required(pass, "Contraseña"), FormUtil.required(extra, "Número empleado"));
                table.setItems(FXCollections.observableArrayList(academicService.usuarios()));
            } catch (Exception ex) { AlertUtil.showError("Error", ex.getMessage()); }
        });
        Button addAlumno = new Button("Agregar alumno");
        addAlumno.setOnAction(e -> {
            try {
                if (carrera.getValue() == null) throw new IllegalArgumentException("Selecciona carrera del alumno.");
                academicService.agregarAlumno(FormUtil.required(nombre, "Nombre"), FormUtil.required(correo, "Correo"), FormUtil.required(pass, "Contraseña"), FormUtil.required(extra, "Matrícula"), carrera.getValue());
                table.setItems(FXCollections.observableArrayList(academicService.usuarios()));
            } catch (Exception ex) { AlertUtil.showError("Error", ex.getMessage()); }
        });

        VBox form = new VBox(8, new Label("Alta de usuarios"), nombre, correo, pass, extra, carrera, addProfesor, addAlumno);
        form.setPadding(new Insets(10));
        form.getStyleClass().add("side-card");
        BorderPane pane = new BorderPane(table);
        pane.setRight(form);
        pane.setPadding(new Insets(14));
        return pane;
    }

    private Parent gruposTab() {
        TableView<Grupo> table = ViewFactory.table();
        table.getColumns().add(ViewFactory.col("ID", "id", 60));
        table.getColumns().add(ViewFactory.col("Nombre", "nombreGrupo", 160));
        table.getColumns().add(ViewFactory.col("Materia ID", "idMateria", 90));
        table.getColumns().add(ViewFactory.col("Profesor ID", "idProfesor", 90));
        table.getColumns().add(ViewFactory.col("Periodo", "periodo", 90));
        table.setItems(FXCollections.observableArrayList(academicService.grupos()));

        ComboBox<Materia> materia = new ComboBox<>(FXCollections.observableArrayList(academicService.materias())); materia.setPromptText("Materia");
        ComboBox<Usuario> profesor = new ComboBox<>(FXCollections.observableArrayList(academicService.profesoresUsuarios())); profesor.setPromptText("Profesor");
        TextField periodo = new TextField("2026-1");
        TextField nombreGrupo = new TextField(); nombreGrupo.setPromptText("Nombre del grupo");
        Button addGrupo = new Button("Crear grupo");
        addGrupo.setOnAction(e -> {
            try {
                if (materia.getValue() == null || profesor.getValue() == null) throw new IllegalArgumentException("Selecciona materia y profesor.");
                academicService.agregarGrupo(materia.getValue(), profesor.getValue(), FormUtil.required(periodo, "Periodo"), FormUtil.required(nombreGrupo, "Grupo"));
                table.setItems(FXCollections.observableArrayList(academicService.grupos()));
            } catch (Exception ex) { AlertUtil.showError("Error", ex.getMessage()); }
        });

        ComboBox<Usuario> alumno = new ComboBox<>(FXCollections.observableArrayList(academicService.alumnosUsuarios())); alumno.setPromptText("Alumno");
        Button inscribir = new Button("Inscribir alumno al grupo seleccionado");
        inscribir.setOnAction(e -> {
            try {
                if (alumno.getValue() == null || table.getSelectionModel().getSelectedItem() == null) throw new IllegalArgumentException("Selecciona alumno y grupo.");
                academicService.inscribirAlumno(alumno.getValue(), table.getSelectionModel().getSelectedItem());
                AlertUtil.showInfo("Inscripción", "Alumno inscrito correctamente.");
            } catch (Exception ex) { AlertUtil.showError("Error", ex.getMessage()); }
        });

        VBox form = new VBox(8, new Label("Crear grupo"), materia, profesor, periodo, nombreGrupo, addGrupo, new Separator(), new Label("Inscripción"), alumno, inscribir);
        form.setPadding(new Insets(10));
        form.getStyleClass().add("side-card");
        BorderPane pane = new BorderPane(table);
        pane.setRight(form);
        pane.setPadding(new Insets(14));
        return pane;
    }

    private Parent calificacionesTab() {
        TableView<GradeRow> table = ViewFactory.table();
        table.getColumns().add(ViewFactory.col("Alumno", "alumno", 200));
        table.getColumns().add(ViewFactory.col("Materia", "materia", 200));
        table.getColumns().add(ViewFactory.col("Grupo", "grupo", 140));
        table.getColumns().add(ViewFactory.col("P1", "parcial1", 60));
        table.getColumns().add(ViewFactory.col("P2", "parcial2", 60));
        table.getColumns().add(ViewFactory.col("P3", "parcial3", 60));
        table.getColumns().add(ViewFactory.col("Act.", "actividades", 60));
        table.getColumns().add(ViewFactory.col("Final", "promedioFinal", 70));
        table.getColumns().add(ViewFactory.col("Estatus", "estatus", 120));
        Runnable refresh = () -> table.setItems(FXCollections.observableArrayList(buildRows(null)));
        refresh.run();

        TextField p1 = new TextField(); p1.setPromptText("P1");
        TextField p2 = new TextField(); p2.setPromptText("P2");
        TextField p3 = new TextField(); p3.setPromptText("P3");
        TextField act = new TextField(); act.setPromptText("Actividades");
        TextField faltas = new TextField("0");
        table.getSelectionModel().selectedItemProperty().addListener((obs, old, row) -> {
            if (row != null) {
                p1.setText(String.valueOf(row.getParcial1()));
                p2.setText(String.valueOf(row.getParcial2()));
                p3.setText(String.valueOf(row.getParcial3()));
                act.setText(String.valueOf(row.getActividades()));
                faltas.setText(String.valueOf(row.getFaltas()));
            }
        });
        Button save = new Button("Guardar y recalcular");
        save.setOnAction(e -> {
            try {
                GradeRow row = table.getSelectionModel().getSelectedItem();
                if (row == null) throw new IllegalArgumentException("Selecciona una inscripción.");
                gradeService.guardarCalificacion(row.getInscripcion(), FormUtil.doubleValue(p1, "P1"), FormUtil.doubleValue(p2, "P2"), FormUtil.doubleValue(p3, "P3"), FormUtil.doubleValue(act, "Actividades"), FormUtil.intValue(faltas, "Faltas"));
                refresh.run();
                AlertUtil.showInfo("Calificación", "Calificación guardada y promedio recalculado.");
            } catch (Exception ex) { AlertUtil.showError("Validación", ex.getMessage()); }
        });
        VBox form = new VBox(8, new Label("Editar calificación"), p1, p2, p3, act, faltas, save);
        form.setPadding(new Insets(10));
        form.getStyleClass().add("side-card");
        BorderPane pane = new BorderPane(table);
        pane.setRight(form);
        pane.setPadding(new Insets(14));
        return pane;
    }

    private java.util.List<GradeRow> buildRows(Integer idProfesor) {
        java.util.List<GradeRow> rows = new java.util.ArrayList<>();
        for (Inscripcion i : academicService.inscripciones()) {
            Grupo grupo = academicService.buscarGrupo(i.getIdGrupo()).orElse(null);
            if (grupo == null) continue;
            if (idProfesor != null && grupo.getIdProfesor() != idProfesor) continue;
            Usuario alumno = academicService.buscarUsuario(i.getIdAlumno()).orElse(null);
            Materia materia = academicService.buscarMateria(grupo.getIdMateria()).orElse(null);
            Calificacion calificacion = gradeService.buscarPorInscripcion(i.getId()).orElse(new Calificacion(0, i.getId(), 0, 0, 0, 0, 0, 0, "SIN EVALUAR"));
            rows.add(new GradeRow(i, calificacion, alumno == null ? "Alumno" : alumno.getNombre(), materia == null ? "Materia" : materia.getNombre(), grupo.getNombreGrupo()));
        }
        return rows;
    }

    public Parent getRoot() { return root; }
}
