package com.rafa.unigrades.pattern;

import com.rafa.unigrades.model.Usuario;

public final class SessionManager {
    private static SessionManager instance;
    private Usuario currentUser;

    private SessionManager() {}

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public Usuario getCurrentUser() { return currentUser; }

    public void login(Usuario usuario) { this.currentUser = usuario; }

    public void logout() { this.currentUser = null; }

    public boolean isLoggedIn() { return currentUser != null; }
}
