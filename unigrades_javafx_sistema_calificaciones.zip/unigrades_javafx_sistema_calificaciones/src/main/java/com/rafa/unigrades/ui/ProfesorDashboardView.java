package com.rafa.unigrades.ui;

import com.rafa.unigrades.controller.MainController;
import com.rafa.unigrades.model.*;
import com.rafa.unigrades.service.AcademicService;
import com.rafa.unigrades.service.GradeService;
import com.rafa.unigrades.util.AlertUtil;
import com.rafa.unigrades.util.FormUtil;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class ProfesorDashboardView {
    private final BorderPane root = new BorderPane();
    private final AcademicService academicService;
    private final GradeService gradeService;
    private final Usuario profesor;

    public ProfesorDashboardView(MainController controller, AcademicService academicService, GradeService gradeService, Usuario profesor) {
        this.academicService = academicService;
        this.gradeService = gradeService;
        this.profesor = profesor;
        root.setTop(header(controller));
        root.setCenter(content());
    }

    private HBox header(MainController controller) {
        Label title = new Label("Panel del Profesor - " + profesor.getNombre());
        title.getStyleClass().add("header-title");
        Button logout = new Button("Cerrar sesión");
        logout.setOnAction(e -> controller.logout());
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox box = new HBox(12, title, spacer, logout);
        box.setPadding(new Insets(14));
        box.getStyleClass().add("header");
        return box;
    }

    private Parent content() {
        TableView<GradeRow> table = ViewFactory.table();
        table.getColumns().add(ViewFactory.col("Alumno", "alumno", 220));
        table.getColumns().add(ViewFactory.col("Materia", "materia", 220));
        table.getColumns().add(ViewFactory.col("Grupo", "grupo", 140));
        table.getColumns().add(ViewFactory.col("P1", "parcial1", 60));
        table.getColumns().add(ViewFactory.col("P2", "parcial2", 60));
        table.getColumns().add(ViewFactory.col("P3", "parcial3", 60));
        table.getColumns().add(ViewFactory.col("Act.", "actividades", 60));
        table.getColumns().add(ViewFactory.col("Faltas", "faltas", 70));
        table.getColumns().add(ViewFactory.col("Final", "promedioFinal", 70));
        table.getColumns().add(ViewFactory.col("Estatus", "estatus", 150));
        Runnable refresh = () -> table.setItems(FXCollections.observableArrayList(buildRows()));
        refresh.run();

        TextField p1 = new TextField(); p1.setPromptText("P1");
        TextField p2 = new TextField(); p2.setPromptText("P2");
        TextField p3 = new TextField(); p3.setPromptText("P3");
        TextField actividades = new TextField(); actividades.setPromptText("Actividades");
        TextField faltas = new TextField("0"); faltas.setPromptText("Faltas");

        table.getSelectionModel().selectedItemProperty().addListener((obs, old, row) -> {
            if (row != null) {
                p1.setText(String.valueOf(row.getParcial1()));
                p2.setText(String.valueOf(row.getParcial2()));
                p3.setText(String.valueOf(row.getParcial3()));
                actividades.setText(String.valueOf(row.getActividades()));
                faltas.setText(String.valueOf(row.getFaltas()));
            }
        });

        Button save = new Button("Guardar calificación");
        save.getStyleClass().add("primary-button");
        save.setOnAction(e -> {
            try {
                GradeRow row = table.getSelectionModel().getSelectedItem();
                if (row == null) throw new IllegalArgumentException("Selecciona un alumno de la tabla.");
                gradeService.guardarCalificacion(row.getInscripcion(), FormUtil.doubleValue(p1, "P1"), FormUtil.doubleValue(p2, "P2"), FormUtil.doubleValue(p3, "P3"), FormUtil.doubleValue(actividades, "Actividades"), FormUtil.intValue(faltas, "Faltas"));
                refresh.run();
                AlertUtil.showInfo("Guardado", "La calificación fue actualizada correctamente.");
            } catch (Exception ex) { AlertUtil.showError("Error de validación", ex.getMessage()); }
        });

        VBox form = new VBox(8, new Label("Captura de calificaciones"), p1, p2, p3, actividades, faltas, save, new Label("Nota: el promedio final se calcula automáticamente con la configuración de la materia."));
        form.setPadding(new Insets(10));
        form.getStyleClass().add("side-card");
        BorderPane pane = new BorderPane(table);
        pane.setRight(form);
        pane.setPadding(new Insets(14));
        return pane;
    }

    private java.util.List<GradeRow> buildRows() {
        java.util.List<GradeRow> rows = new java.util.ArrayList<>();
        for (Grupo grupo : academicService.gruposPorProfesor(profesor.getId())) {
            for (Inscripcion i : academicService.inscripcionesPorGrupo(grupo.getId())) {
                Usuario alumno = academicService.buscarUsuario(i.getIdAlumno()).orElse(null);
                Materia materia = academicService.buscarMateria(grupo.getIdMateria()).orElse(null);
                Calificacion calificacion = gradeService.buscarPorInscripcion(i.getId()).orElse(new Calificacion(0, i.getId(), 0, 0, 0, 0, 0, 0, "SIN EVALUAR"));
                rows.add(new GradeRow(i, calificacion, alumno == null ? "Alumno" : alumno.getNombre(), materia == null ? "Materia" : materia.getNombre(), grupo.getNombreGrupo()));
            }
        }
        return rows;
    }

    public Parent getRoot() { return root; }
}
