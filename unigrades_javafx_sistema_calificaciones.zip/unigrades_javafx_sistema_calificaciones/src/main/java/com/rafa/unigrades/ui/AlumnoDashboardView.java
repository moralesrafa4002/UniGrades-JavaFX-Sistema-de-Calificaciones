package com.rafa.unigrades.ui;

import com.rafa.unigrades.controller.MainController;
import com.rafa.unigrades.model.*;
import com.rafa.unigrades.service.AcademicService;
import com.rafa.unigrades.service.GradeService;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class AlumnoDashboardView {
    private final BorderPane root = new BorderPane();
    private final AcademicService academicService;
    private final GradeService gradeService;
    private final Usuario alumno;

    public AlumnoDashboardView(MainController controller, AcademicService academicService, GradeService gradeService, Usuario alumno) {
        this.academicService = academicService;
        this.gradeService = gradeService;
        this.alumno = alumno;
        root.setTop(header(controller));
        root.setCenter(content());
    }

    private HBox header(MainController controller) {
        Label title = new Label("Panel del Alumno - " + alumno.getNombre());
        title.getStyleClass().add("header-title");
        Button logout = new Button("Cerrar sesión");
        logout.setOnAction(e -> controller.logout());
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox box = new HBox(12, title, spacer, logout);
        box.setPadding(new Insets(14));
        box.getStyleClass().add("header");
        return box;
    }

    private Parent content() {
        Label description = new Label("Consulta de calificaciones parciales, actividades, promedio final y estatus académico.");
        description.getStyleClass().add("subtitle");

        TableView<GradeRow> table = ViewFactory.table();
        table.getColumns().add(ViewFactory.col("Materia", "materia", 240));
        table.getColumns().add(ViewFactory.col("Grupo", "grupo", 150));
        table.getColumns().add(ViewFactory.col("Parcial 1", "parcial1", 80));
        table.getColumns().add(ViewFactory.col("Parcial 2", "parcial2", 80));
        table.getColumns().add(ViewFactory.col("Parcial 3", "parcial3", 80));
        table.getColumns().add(ViewFactory.col("Actividades", "actividades", 90));
        table.getColumns().add(ViewFactory.col("Faltas", "faltas", 70));
        table.getColumns().add(ViewFactory.col("Final", "promedioFinal", 80));
        table.getColumns().add(ViewFactory.col("Estatus", "estatus", 160));
        table.setItems(FXCollections.observableArrayList(buildRows()));

        VBox box = new VBox(12, description, table);
        box.setPadding(new Insets(18));
        return box;
    }

    private java.util.List<GradeRow> buildRows() {
        java.util.List<GradeRow> rows = new java.util.ArrayList<>();
        for (Inscripcion i : academicService.inscripcionesPorAlumno(alumno.getId())) {
            Grupo grupo = academicService.buscarGrupo(i.getIdGrupo()).orElse(null);
            if (grupo == null) continue;
            Materia materia = academicService.buscarMateria(grupo.getIdMateria()).orElse(null);
            Calificacion calificacion = gradeService.buscarPorInscripcion(i.getId()).orElse(new Calificacion(0, i.getId(), 0, 0, 0, 0, 0, 0, "SIN EVALUAR"));
            rows.add(new GradeRow(i, calificacion, alumno.getNombre(), materia == null ? "Materia" : materia.getNombre(), grupo.getNombreGrupo()));
        }
        return rows;
    }

    public Parent getRoot() { return root; }
}
