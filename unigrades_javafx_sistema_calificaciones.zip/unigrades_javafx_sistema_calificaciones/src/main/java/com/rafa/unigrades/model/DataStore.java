package com.rafa.unigrades.model;

import java.util.ArrayList;
import java.util.List;

public class DataStore {
    private Universidad universidad = new Universidad(1, "Universidad Demo");
    private final List<Usuario> usuarios = new ArrayList<>();
    private final List<Alumno> alumnos = new ArrayList<>();
    private final List<Profesor> profesores = new ArrayList<>();
    private final List<Administrador> administradores = new ArrayList<>();
    private final List<Carrera> carreras = new ArrayList<>();
    private final List<Semestre> semestres = new ArrayList<>();
    private final List<Materia> materias = new ArrayList<>();
    private final List<Grupo> grupos = new ArrayList<>();
    private final List<Inscripcion> inscripciones = new ArrayList<>();
    private final List<ConfiguracionEvaluacion> configuraciones = new ArrayList<>();
    private final List<Calificacion> calificaciones = new ArrayList<>();

    public Universidad getUniversidad() { return universidad; }
    public void setUniversidad(Universidad universidad) { this.universidad = universidad; }
    public List<Usuario> getUsuarios() { return usuarios; }
    public List<Alumno> getAlumnos() { return alumnos; }
    public List<Profesor> getProfesores() { return profesores; }
    public List<Administrador> getAdministradores() { return administradores; }
    public List<Carrera> getCarreras() { return carreras; }
    public List<Semestre> getSemestres() { return semestres; }
    public List<Materia> getMaterias() { return materias; }
    public List<Grupo> getGrupos() { return grupos; }
    public List<Inscripcion> getInscripciones() { return inscripciones; }
    public List<ConfiguracionEvaluacion> getConfiguraciones() { return configuraciones; }
    public List<Calificacion> getCalificaciones() { return calificaciones; }

    public int nextUsuarioId() { return usuarios.stream().mapToInt(Usuario::getId).max().orElse(0) + 1; }
    public int nextCarreraId() { return carreras.stream().mapToInt(Carrera::getId).max().orElse(0) + 1; }
    public int nextSemestreId() { return semestres.stream().mapToInt(Semestre::getId).max().orElse(0) + 1; }
    public int nextMateriaId() { return materias.stream().mapToInt(Materia::getId).max().orElse(0) + 1; }
    public int nextGrupoId() { return grupos.stream().mapToInt(Grupo::getId).max().orElse(0) + 1; }
    public int nextInscripcionId() { return inscripciones.stream().mapToInt(Inscripcion::getId).max().orElse(0) + 1; }
    public int nextConfiguracionId() { return configuraciones.stream().mapToInt(ConfiguracionEvaluacion::getId).max().orElse(0) + 1; }
    public int nextCalificacionId() { return calificaciones.stream().mapToInt(Calificacion::getId).max().orElse(0) + 1; }
}
