package com.rafa.unigrades.persistence;

import com.rafa.unigrades.model.*;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.nio.file.Files;
import java.nio.file.Path;

public class XmlDatabase {
    private final Path filePath;

    public XmlDatabase(Path filePath) {
        this.filePath = filePath;
    }

    public DataStore loadOrCreate() {
        try {
            if (Files.notExists(filePath)) {
                Files.createDirectories(filePath.getParent());
                DataStore seed = new SeedDataFactory().createDefaultData();
                save(seed);
                return seed;
            }
            return load();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo inicializar la base XML: " + e.getMessage(), e);
        }
    }

    public DataStore load() throws Exception {
        DataStore store = new DataStore();
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document document = builder.parse(filePath.toFile());
        Element root = document.getDocumentElement();

        Element universidad = first(root, "universidad");
        if (universidad != null) {
            store.setUniversidad(new Universidad(intAttr(universidad, "id"), attr(universidad, "nombre")));
        }

        forEach(root, "usuario", e -> store.getUsuarios().add(new Usuario(
                intAttr(e, "id"), attr(e, "nombre"), attr(e, "correo"), attr(e, "password"), TipoUsuario.valueOf(attr(e, "tipo"))
        )));
        forEach(root, "administrador", e -> store.getAdministradores().add(new Administrador(intAttr(e, "idUsuario"), attr(e, "numeroEmpleado"))));
        forEach(root, "profesor", e -> store.getProfesores().add(new Profesor(intAttr(e, "idUsuario"), attr(e, "numeroEmpleado"))));
        forEach(root, "alumno", e -> store.getAlumnos().add(new Alumno(intAttr(e, "idUsuario"), attr(e, "matricula"), intAttr(e, "idCarrera"))));
        forEach(root, "carrera", e -> store.getCarreras().add(new Carrera(intAttr(e, "id"), attr(e, "nombre"), intAttr(e, "idUniversidad"))));
        forEach(root, "semestre", e -> store.getSemestres().add(new Semestre(intAttr(e, "id"), intAttr(e, "numero"))));
        forEach(root, "materia", e -> store.getMaterias().add(new Materia(intAttr(e, "id"), attr(e, "nombre"), intAttr(e, "idCarrera"), intAttr(e, "idSemestre"))));
        forEach(root, "grupo", e -> store.getGrupos().add(new Grupo(intAttr(e, "id"), intAttr(e, "idMateria"), intAttr(e, "idProfesor"), attr(e, "periodo"), attr(e, "nombreGrupo"))));
        forEach(root, "inscripcion", e -> store.getInscripciones().add(new Inscripcion(intAttr(e, "id"), intAttr(e, "idAlumno"), intAttr(e, "idGrupo"))));
        forEach(root, "configuracion", e -> store.getConfiguraciones().add(new ConfiguracionEvaluacion(
                intAttr(e, "id"), intAttr(e, "idMateria"), doubleAttr(e, "porcentajeParciales"), doubleAttr(e, "porcentajeActividades"), doubleAttr(e, "calificacionMinima"), intAttr(e, "faltasMaximas")
        )));
        forEach(root, "calificacion", e -> store.getCalificaciones().add(new Calificacion(
                intAttr(e, "id"), intAttr(e, "idInscripcion"), doubleAttr(e, "parcial1"), doubleAttr(e, "parcial2"), doubleAttr(e, "parcial3"), doubleAttr(e, "actividades"), intAttr(e, "faltas"), doubleAttr(e, "promedioFinal"), attr(e, "estatus")
        )));
        return store;
    }

    public void save(DataStore store) {
        try {
            Files.createDirectories(filePath.getParent());
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = builder.newDocument();
            Element root = doc.createElement("unigrades");
            doc.appendChild(root);

            Element universidad = doc.createElement("universidad");
            universidad.setAttribute("id", String.valueOf(store.getUniversidad().getId()));
            universidad.setAttribute("nombre", store.getUniversidad().getNombre());
            root.appendChild(universidad);

            Element usuarios = section(doc, root, "usuarios");
            for (Usuario u : store.getUsuarios()) {
                Element e = doc.createElement("usuario");
                e.setAttribute("id", String.valueOf(u.getId()));
                e.setAttribute("nombre", u.getNombre());
                e.setAttribute("correo", u.getCorreo());
                e.setAttribute("password", u.getPassword());
                e.setAttribute("tipo", u.getTipo().name());
                usuarios.appendChild(e);
            }

            Element administradores = section(doc, root, "administradores");
            for (Administrador a : store.getAdministradores()) {
                Element e = doc.createElement("administrador");
                e.setAttribute("idUsuario", String.valueOf(a.getIdUsuario()));
                e.setAttribute("numeroEmpleado", a.getNumeroEmpleado());
                administradores.appendChild(e);
            }

            Element profesores = section(doc, root, "profesores");
            for (Profesor p : store.getProfesores()) {
                Element e = doc.createElement("profesor");
                e.setAttribute("idUsuario", String.valueOf(p.getIdUsuario()));
                e.setAttribute("numeroEmpleado", p.getNumeroEmpleado());
                profesores.appendChild(e);
            }

            Element alumnos = section(doc, root, "alumnos");
            for (Alumno a : store.getAlumnos()) {
                Element e = doc.createElement("alumno");
                e.setAttribute("idUsuario", String.valueOf(a.getIdUsuario()));
                e.setAttribute("matricula", a.getMatricula());
                e.setAttribute("idCarrera", String.valueOf(a.getIdCarrera()));
                alumnos.appendChild(e);
            }

            Element carreras = section(doc, root, "carreras");
            for (Carrera c : store.getCarreras()) {
                Element e = doc.createElement("carrera");
                e.setAttribute("id", String.valueOf(c.getId()));
                e.setAttribute("nombre", c.getNombre());
                e.setAttribute("idUniversidad", String.valueOf(c.getIdUniversidad()));
                carreras.appendChild(e);
            }

            Element semestres = section(doc, root, "semestres");
            for (Semestre s : store.getSemestres()) {
                Element e = doc.createElement("semestre");
                e.setAttribute("id", String.valueOf(s.getId()));
                e.setAttribute("numero", String.valueOf(s.getNumero()));
                semestres.appendChild(e);
            }

            Element materias = section(doc, root, "materias");
            for (Materia m : store.getMaterias()) {
                Element e = doc.createElement("materia");
                e.setAttribute("id", String.valueOf(m.getId()));
                e.setAttribute("nombre", m.getNombre());
                e.setAttribute("idCarrera", String.valueOf(m.getIdCarrera()));
                e.setAttribute("idSemestre", String.valueOf(m.getIdSemestre()));
                materias.appendChild(e);
            }

            Element grupos = section(doc, root, "grupos");
            for (Grupo g : store.getGrupos()) {
                Element e = doc.createElement("grupo");
                e.setAttribute("id", String.valueOf(g.getId()));
                e.setAttribute("idMateria", String.valueOf(g.getIdMateria()));
                e.setAttribute("idProfesor", String.valueOf(g.getIdProfesor()));
                e.setAttribute("periodo", g.getPeriodo());
                e.setAttribute("nombreGrupo", g.getNombreGrupo());
                grupos.appendChild(e);
            }

            Element inscripciones = section(doc, root, "inscripciones");
            for (Inscripcion i : store.getInscripciones()) {
                Element e = doc.createElement("inscripcion");
                e.setAttribute("id", String.valueOf(i.getId()));
                e.setAttribute("idAlumno", String.valueOf(i.getIdAlumno()));
                e.setAttribute("idGrupo", String.valueOf(i.getIdGrupo()));
                inscripciones.appendChild(e);
            }

            Element configuraciones = section(doc, root, "configuraciones");
            for (ConfiguracionEvaluacion c : store.getConfiguraciones()) {
                Element e = doc.createElement("configuracion");
                e.setAttribute("id", String.valueOf(c.getId()));
                e.setAttribute("idMateria", String.valueOf(c.getIdMateria()));
                e.setAttribute("porcentajeParciales", String.valueOf(c.getPorcentajeParciales()));
                e.setAttribute("porcentajeActividades", String.valueOf(c.getPorcentajeActividades()));
                e.setAttribute("calificacionMinima", String.valueOf(c.getCalificacionMinima()));
                e.setAttribute("faltasMaximas", String.valueOf(c.getFaltasMaximas()));
                configuraciones.appendChild(e);
            }

            Element calificaciones = section(doc, root, "calificaciones");
            for (Calificacion c : store.getCalificaciones()) {
                Element e = doc.createElement("calificacion");
                e.setAttribute("id", String.valueOf(c.getId()));
                e.setAttribute("idInscripcion", String.valueOf(c.getIdInscripcion()));
                e.setAttribute("parcial1", String.valueOf(c.getParcial1()));
                e.setAttribute("parcial2", String.valueOf(c.getParcial2()));
                e.setAttribute("parcial3", String.valueOf(c.getParcial3()));
                e.setAttribute("actividades", String.valueOf(c.getActividades()));
                e.setAttribute("faltas", String.valueOf(c.getFaltas()));
                e.setAttribute("promedioFinal", String.valueOf(c.getPromedioFinal()));
                e.setAttribute("estatus", c.getEstatus());
                calificaciones.appendChild(e);
            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(new DOMSource(doc), new StreamResult(filePath.toFile()));
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo guardar la base XML: " + e.getMessage(), e);
        }
    }

    private static Element section(Document doc, Element root, String name) {
        Element element = doc.createElement(name);
        root.appendChild(element);
        return element;
    }

    private static Element first(Element root, String tag) {
        NodeList list = root.getElementsByTagName(tag);
        return list.getLength() > 0 ? (Element) list.item(0) : null;
    }

    private static void forEach(Element root, String tag, ElementConsumer consumer) throws Exception {
        NodeList list = root.getElementsByTagName(tag);
        for (int i = 0; i < list.getLength(); i++) {
            consumer.accept((Element) list.item(i));
        }
    }

    private static String attr(Element e, String name) { return e.getAttribute(name); }
    private static int intAttr(Element e, String name) { return Integer.parseInt(e.getAttribute(name)); }
    private static double doubleAttr(Element e, String name) { return Double.parseDouble(e.getAttribute(name)); }

    private interface ElementConsumer {
        void accept(Element e) throws Exception;
    }
}
