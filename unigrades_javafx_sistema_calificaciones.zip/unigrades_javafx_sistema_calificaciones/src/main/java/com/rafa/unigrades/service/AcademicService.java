package com.rafa.unigrades.service;

import com.rafa.unigrades.model.*;
import com.rafa.unigrades.repository.RepositoryContext;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class AcademicService {
    private final RepositoryContext context;

    public AcademicService(RepositoryContext context) {
        this.context = context;
    }

    public List<Carrera> carreras() { return context.getStore().getCarreras(); }
    public List<Semestre> semestres() { return context.getStore().getSemestres(); }
    public List<Materia> materias() { return context.getStore().getMaterias(); }
    public List<Usuario> usuarios() { return context.getStore().getUsuarios(); }
    public List<Grupo> grupos() { return context.getStore().getGrupos(); }
    public List<Inscripcion> inscripciones() { return context.getStore().getInscripciones(); }
    public List<Alumno> alumnos() { return context.getStore().getAlumnos(); }
    public List<Profesor> profesores() { return context.getStore().getProfesores(); }
    public List<ConfiguracionEvaluacion> configuraciones() { return context.getStore().getConfiguraciones(); }

    public Carrera agregarCarrera(String nombre) {
        Carrera carrera = new Carrera(context.getStore().nextCarreraId(), nombre, context.getStore().getUniversidad().getId());
        context.getStore().getCarreras().add(carrera);
        context.save();
        return carrera;
    }

    public Materia agregarMateria(String nombre, Carrera carrera, Semestre semestre, double porcentajeParciales, double porcentajeActividades, double minima, int faltasMaximas) {
        if (Math.round((porcentajeParciales + porcentajeActividades) * 100.0) / 100.0 != 100.0) {
            throw new IllegalArgumentException("Los porcentajes de evaluación deben sumar exactamente 100%.");
        }
        Materia materia = new Materia(context.getStore().nextMateriaId(), nombre, carrera.getId(), semestre.getId());
        context.getStore().getMaterias().add(materia);
        context.getStore().getConfiguraciones().add(new ConfiguracionEvaluacion(context.getStore().nextConfiguracionId(), materia.getId(), porcentajeParciales, porcentajeActividades, minima, faltasMaximas));
        context.save();
        return materia;
    }

    public Usuario agregarProfesor(String nombre, String correo, String password, String numeroEmpleado) {
        Usuario usuario = new Usuario(context.getStore().nextUsuarioId(), nombre, correo, password, TipoUsuario.PROFESOR);
        context.getStore().getUsuarios().add(usuario);
        context.getStore().getProfesores().add(new Profesor(usuario.getId(), numeroEmpleado));
        context.save();
        return usuario;
    }

    public Usuario agregarAlumno(String nombre, String correo, String password, String matricula, Carrera carrera) {
        Usuario usuario = new Usuario(context.getStore().nextUsuarioId(), nombre, correo, password, TipoUsuario.ALUMNO);
        context.getStore().getUsuarios().add(usuario);
        context.getStore().getAlumnos().add(new Alumno(usuario.getId(), matricula, carrera.getId()));
        context.save();
        return usuario;
    }

    public Grupo agregarGrupo(Materia materia, Usuario profesor, String periodo, String nombreGrupo) {
        Grupo grupo = new Grupo(context.getStore().nextGrupoId(), materia.getId(), profesor.getId(), periodo, nombreGrupo);
        context.getStore().getGrupos().add(grupo);
        context.save();
        return grupo;
    }

    public Inscripcion inscribirAlumno(Usuario alumno, Grupo grupo) {
        boolean exists = context.getStore().getInscripciones().stream()
                .anyMatch(i -> i.getIdAlumno() == alumno.getId() && i.getIdGrupo() == grupo.getId());
        if (exists) {
            throw new IllegalArgumentException("El alumno ya está inscrito en este grupo.");
        }
        Inscripcion inscripcion = new Inscripcion(context.getStore().nextInscripcionId(), alumno.getId(), grupo.getId());
        context.getStore().getInscripciones().add(inscripcion);
        context.getStore().getCalificaciones().add(new Calificacion(context.getStore().nextCalificacionId(), inscripcion.getId(), 0, 0, 0, 0, 0, 0, "SIN EVALUAR"));
        context.save();
        return inscripcion;
    }

    public List<Usuario> profesoresUsuarios() {
        return context.getStore().getUsuarios().stream().filter(u -> u.getTipo() == TipoUsuario.PROFESOR).collect(Collectors.toList());
    }

    public List<Usuario> alumnosUsuarios() {
        return context.getStore().getUsuarios().stream().filter(u -> u.getTipo() == TipoUsuario.ALUMNO).collect(Collectors.toList());
    }

    public List<Grupo> gruposPorProfesor(int idProfesor) {
        return context.getStore().getGrupos().stream().filter(g -> g.getIdProfesor() == idProfesor).collect(Collectors.toList());
    }

    public List<Inscripcion> inscripcionesPorAlumno(int idAlumno) {
        return context.getStore().getInscripciones().stream().filter(i -> i.getIdAlumno() == idAlumno).collect(Collectors.toList());
    }

    public List<Inscripcion> inscripcionesPorGrupo(int idGrupo) {
        return context.getStore().getInscripciones().stream().filter(i -> i.getIdGrupo() == idGrupo).collect(Collectors.toList());
    }

    public Optional<Usuario> buscarUsuario(int id) { return context.getStore().getUsuarios().stream().filter(u -> u.getId() == id).findFirst(); }
    public Optional<Materia> buscarMateria(int id) { return context.getStore().getMaterias().stream().filter(m -> m.getId() == id).findFirst(); }
    public Optional<Grupo> buscarGrupo(int id) { return context.getStore().getGrupos().stream().filter(g -> g.getId() == id).findFirst(); }
    public Optional<Carrera> buscarCarrera(int id) { return context.getStore().getCarreras().stream().filter(c -> c.getId() == id).findFirst(); }

    public void eliminarCarrera(Carrera carrera) {
        context.getStore().getCarreras().remove(carrera);
        context.save();
    }

    public void eliminarMateria(Materia materia) {
        context.getStore().getMaterias().remove(materia);
        context.getStore().getConfiguraciones().removeIf(c -> c.getIdMateria() == materia.getId());
        context.save();
    }

    public void guardarCambios() { context.save(); }
}
