package com.rafa.unigrades.ui;

import com.rafa.unigrades.model.Calificacion;
import com.rafa.unigrades.model.Inscripcion;

public class GradeRow {
    private final Inscripcion inscripcion;
    private final Calificacion calificacion;
    private final String alumno;
    private final String materia;
    private final String grupo;

    public GradeRow(Inscripcion inscripcion, Calificacion calificacion, String alumno, String materia, String grupo) {
        this.inscripcion = inscripcion;
        this.calificacion = calificacion;
        this.alumno = alumno;
        this.materia = materia;
        this.grupo = grupo;
    }

    public Inscripcion getInscripcion() { return inscripcion; }
    public Calificacion getCalificacion() { return calificacion; }
    public String getAlumno() { return alumno; }
    public String getMateria() { return materia; }
    public String getGrupo() { return grupo; }
    public double getParcial1() { return calificacion.getParcial1(); }
    public double getParcial2() { return calificacion.getParcial2(); }
    public double getParcial3() { return calificacion.getParcial3(); }
    public double getActividades() { return calificacion.getActividades(); }
    public int getFaltas() { return calificacion.getFaltas(); }
    public double getPromedioFinal() { return calificacion.getPromedioFinal(); }
    public String getEstatus() { return calificacion.getEstatus(); }
}
