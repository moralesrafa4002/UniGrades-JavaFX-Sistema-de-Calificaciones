# Manifiesto de archivos

Este archivo resume los elementos principales incluidos en el proyecto.

## Código fuente

- `src/main/java/com/rafa/unigrades/App.java`: punto de entrada de JavaFX.
- `model/`: entidades del sistema.
- `service/`: lógica de negocio.
- `ui/`: pantallas JavaFX.
- `controller/`: navegación y control de sesión.
- `persistence/`: lectura y escritura XML.
- `pattern/`: patrones de diseño.
- `util/`: utilidades y validaciones.

## Documentación

- `docs/00_resumen_proyecto.md`: resumen general.
- `docs/01_requerimientos_funcionales.md`: requerimientos por rol.
- `docs/02_modelo_datos.md`: entidades y relaciones.
- `docs/03_arquitectura_mvc.md`: arquitectura y capas.
- `docs/04_patrones_diseno.md`: patrones implementados.
- `docs/05_persistencia_xml.md`: persistencia local.
- `docs/06_manual_usuario.md`: manual de uso.
- `docs/07_defensa_individual.md`: guía para explicar el proyecto.
- `docs/08_pruebas_validaciones.md`: pruebas y validaciones.
- `docs/09_referencias.md`: referencias.

## Diagramas

- `diagrams/codigo_mermaid/`: código editable Mermaid.
- `diagrams/codigo_dot/`: código editable DOT.
- `diagrams/imagenes_png/`: imágenes generadas de diagramas.

## Datos

- `data/university-data.xml`: datos persistentes de prueba.

## Scripts

- `scripts/run_windows.bat`: ejecutar en Windows.
- `scripts/run_linux_mac.sh`: ejecutar en Linux/Mac.
- `scripts/git_push_template.sh`: plantilla para subir a GitHub.
